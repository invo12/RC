from GUI import MainApp
from GetApiData import  GetAPI
from socket import *




GetAPI().getCursValutar("eur")
GetAPI().getNews("bitcoin")
GetAPI().getWeather("Iasi")
GetAPI().getRandom()

#if __name__=="__main__":
#    a=MainApp()
#    b = GetAPI().getData()
#    a.startMainProgramLoop()



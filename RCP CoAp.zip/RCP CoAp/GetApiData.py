from socket import *
import datetime
import json


class GetAPI():
    def __init__(self):
        #print("Init")
        pass

    def getCursValutar(self,valuta):
        now = datetime.datetime.now()
        s = socket(AF_INET, SOCK_STREAM)
        s.connect(("www.infovalutar.ro", 80))
        request = "GET /bnr/"+str(now.year)+"/"+str(now.month)+"/"+str(now.day)+"/"+valuta+" HTTP/1.1\r\nHost: infovalutar.ro\r\n\r\n"
        s.send(request.encode())
        response = s.recv(4096)
        response = response.decode()
        y = response.rfind('\n')
        print(float(response[y+1:]))
        s.close()
        return float(response[y+1:])

    def getWeather(self,locatie):
        s = socket(AF_INET, SOCK_STREAM)
        s.connect(("api.openweathermap.org", 80))
        request = "GET /data/2.5/weather?q="+locatie+"&APPID=8a999283783fff58a906c31b2e47a26d HTTP/1.1\r\nHost: api.openweathermap.org\r\n\r\n"
        s.send(request.encode())
        response = s.recv(4096)
        response = response.decode()
        y = response.rfind('\n')
        print(response[y + 1:])
        return response[y + 1:]

    def getNews(self,info):
        s = socket(AF_INET, SOCK_STREAM)
        now = datetime.datetime.now()
        s.connect(("www.newsapi.org", 80))
        request = "GET https://newsapi.org/v2/everything?q="+info+"&from="+str(now.year)+"-"+str(now.month)+"-"+str(now.day)+"&sortBy=publishedAt&apiKey=b258b93e89444d50a93ded4de7d4e21e  HTTP/1.1\r\nHost: newsapi.org/\r\n\r\n"
        s.send(request.encode())
        response = s.recv(4096)
        response = response.decode()
        y = response.rfind('\n')
        print(response[y + 1:])
        return response[y + 1:]

    def getRandom(self):
        print("\n\n\n\n\n")
        s = socket(AF_INET, SOCK_STREAM)
        s.connect(("api.random.org", 80))
        data = {
            'jsonrpc': '2.0',
            'method': 'generateIntegers',
            'params': {
                'apiKey': '956b8908-d54c-464b-92d7-f4e8c5bdf0a7',
                'n': 10,
                'min': 1,
                'max': 10,
                'replacement': 'true',
                'base': 10
            },
            'id': 42
        }
        jsonString = json.dumps(data)
        request = "POST /json-rpc/2/invoke HTTP/1.1\r\nHost: api.random.org\r\n data:"+jsonString+"\r\n\r\n"
        s.send(request.encode())
        response = s.recv(4096)
        response = response.decode()
        print(response)






import tkinter
from tkinter import *
from tkinter import ttk


class MainApp():
    def __init__(self):
        self.root=Tk()
        self.root.geometry("800x600");

    def startMainProgramLoop(self):
        self.root.mainloop()